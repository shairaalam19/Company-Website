$(document).ready();
var i = -1;
scaffolding.addEventListener('click', function(){
    i++; //increments
    i = colorClicker(i);
});

//goes through each of the colors in the array as the user clicks 
function colorClicker(i){
    var color = ['#ddc0a4', '#e0b791', '#d4b190', '#b9926e', '#a77d57', '#966943', '#774d2a'];
    if(i < color.length){
        $('#scaffolding').css('background-color', color[i]);
        $('#scaffolding').css('border-color', color[i]);
        return i;
    }
    else if(i >= color.length) {
        i = 0;
        $('#scaffolding').css('background-color', color[i]);
        $('#scaffolding').css('border-color', color[i]);
        return i; //returns restarted value of i
    }
} 

//Slideshow
$('#slideshow > div:gt(0)').hide();

setInterval(function(){
    $('#slideshow > div:first').fadeOut(1000).next().fadeIn(1000).end().appendTo('#slideshow');
},4000);

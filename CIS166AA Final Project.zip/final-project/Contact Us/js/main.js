function validate(){
//validate all the elements of the form
    var element = contact.elements;   

//create a variable called canSubmit and set it to a boolean of true
    var canSubmit = true;
   
    //write a for loop that checks the value of each form field. If the form field is not completed, then canSubmit will be false
  
    for(var i = 0; i < element.length; i++){
        if(element[i].type == 'text' || element[i].type == 'email'){
            if(element[i].value == ""){
                canSubmit = false; //sets the value to false if it is empty
            }
        }
    }
    // if (ProjectProposal.textContent == ""){
    //         canSubmit = false;
    // }      
    if(canSubmit == true){
        submit.disabled = false; //if each element fits the requirements, then the submit button will no longer be disabled
    }
    console.log(canSubmit);
    return canSubmit;
}  

window.addEventListener('load', function(e){
    document.getElementById('flname').focus();
    //in an event listener, add a method to prevent default submission of the form. 
    e.preventDefault();
});

submit.disabled = true;
validate();

flname.addEventListener('blur', function(){
    validate();
});
email.addEventListener('blur', function(){
    validate();
});
company.addEventListener('blur', function(){
    validate();
});

submit.addEventListener("click", function(e){
    // create an alert if form is submitted that states a confirmation message
    var check = validate();
    if(check == true){
        msg.innerHTML = 'Thank you <b>' + flname.value + '</b> for considering Alam Engineering! We will be contacting you shortly at <b>' + email.value + '</b>.';
    }
    else{
        alert('You have not submitted all the criteria. Please fill out.');
    }
    
    // make sure this event listener contains code to reset the form
    e.preventDefault();
});

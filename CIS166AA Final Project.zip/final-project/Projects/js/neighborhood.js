submit.addEventListener('click', function(e){
    var total = ((land.value/lot.value) * ((lotValue.value * 0.2) + (houseValue.value * 0.12))); //evaluates cost based on certain requirements

    //charges certain percentage depending on type of neighborhood 
    if(neighStyle.value === "luxury")
    {
        total *= 1.47;
    }
    else if(neighStyle.value === "downUrban")
    {
        total *= 1.42;
    }
    else if(neighStyle.value === "suburban")
    {
        total *= 1.27;
    }
    else if(neighStyle.value === "apartment")
    {
        total *= 1.36;
    }
    else if(neighStyle.value === "luxApart")
    {
        total *= 1.49;
    }

    var formatter = new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: 'USD',
    });
      
    total = formatter.format(total);
    
    if(neighStyle.value === 'other' || total == '$NaN'){
        bridgeTotal.innerHTML = 'We cannot calculate a proper estimate. Please specify what type of land it is over.'
    }
    else {
        bridgeTotal.innerHTML = 'The minimum estimated total cost is: <b>' + total + '</b>.';
    }
    e.preventDefault();
});
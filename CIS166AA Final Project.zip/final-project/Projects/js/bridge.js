submit.addEventListener('click', function(e){
    var total = (height.value * width.value * 1.08) + 1500; //calculates with additional fee

    //multiplies total with a certain percentage depending on what it is over
    if(overbridge.value === "busy")
    {
        total *= 1.27;
    }
    else if(overbridge.value === "service"){
        total *= 1.15;
    }
    else if(overbridge.value === "water"){
        total *= 1.392;
    }
    var formatter = new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: 'USD',
    });
      
    total = formatter.format(total);
    
    if(overbridge.value === 'other'){
        bridgeTotal.innerHTML = 'We cannot calculate a proper estimate. Please specify what type of land it is over.'
    }
    else {
        bridgeTotal.innerHTML = 'The minimum estimated total cost is: <b>' + total + '</b>.';
    }
    e.preventDefault();
});